import {
  getAllTaches,
  getTacheById,
  createTache,
  updateTache,
  deleteTache,
  getStatsImplication,
} from '../models/tache.model.js'
import { getSousEquipesByResponsable, sousEquipeAppartientAuResponsable } from '../models/sousEquipe.model.js'
import { creerNotification, getNomAuteur } from '../models/notification.model.js'

// Notifie le collaborateur qu'une tâche vient de lui être assignée, en précisant
// qui l'a assignée (admin ou responsable — jamais un autre collaborateur).
async function notifierTacheAssignee(tache, auteur) {
  if (!tache?.id_collaborateur) return
  try {
    const nomAuteur = await getNomAuteur(auteur.role, auteur.id)
    await creerNotification({
      id_utilisateur: tache.id_collaborateur,
      type_utilisateur: 'collaborateur',
      type: 'tache_assignee',
      titre: 'Nouvelle tâche assignée',
      message: `${nomAuteur} vous a assigné la tâche "${tache.titre}"`,
      lien_page: 'taches',
    })
  } catch (err) {
    console.error('Erreur notification tâche assignée:', err)
  }
}

export async function listTaches(req, res) {
  try {
    const { collaborateur } = req.query
    let sousEquipeId = req.query.sous_equipe

    // Un responsable ne voit que les tâches de sa (ses) propre(s) sous-équipe(s).
    if (req.user.role === 'responsable') {
      const mesEquipes = await getSousEquipesByResponsable(req.user.id)
      const mesIds = mesEquipes.map((e) => e.id)
      if (sousEquipeId && !mesIds.includes(Number(sousEquipeId))) {
        return res.status(403).json({ message: "Cette sous-équipe ne vous est pas assignée." })
      }
      if (!sousEquipeId) sousEquipeId = mesIds[0]
    }

    const taches = await getAllTaches({ sousEquipeId, collaborateurId: collaborateur })
    res.json(taches)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Erreur serveur' })
  }
}

// "Mes tâches" — le collaborateur connecté consulte ses propres tâches.
export async function listMesTaches(req, res) {
  try {
    const taches = await getAllTaches({ collaborateurId: req.user.id })
    res.json(taches)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Erreur serveur' })
  }
}

export async function addTache(req, res) {
  try {
    const { titre } = req.body
    if (!titre) return res.status(400).json({ message: 'Le titre est requis.' })
    if (req.user.role === 'responsable') {
      const ok = await sousEquipeAppartientAuResponsable(req.body.id_sous_equipe, req.user.id)
      if (!ok) return res.status(403).json({ message: "Cette sous-équipe ne vous est pas assignée." })
    }
    const created = await createTache(req.body)
    notifierTacheAssignee(created, { id: req.user.id, role: req.user.role })
    res.status(201).json(created)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Erreur serveur' })
  }
}

// Statuts que le collaborateur est autorisé à choisir lui-même pour ses tâches
// (cahier des charges : En cours, Faite, Problème de coordination).
const STATUTS_AUTORISES_COLLABORATEUR = ['en_cours', 'validee', 'probleme_coordination']

export async function editTache(req, res) {
  try {
    // Un responsable ne peut modifier que les tâches de sa propre sous-équipe
    // (titre, description, priorité, échéance, assignation, statut).
    if (req.user.role === 'responsable') {
      const tache = await getTacheById(req.params.id)
      if (!tache) return res.status(404).json({ message: 'Tâche introuvable.' })
      const ok = await sousEquipeAppartientAuResponsable(tache.id_sous_equipe, req.user.id)
      if (!ok) return res.status(403).json({ message: 'Vous ne pouvez modifier que les tâches de votre équipe.' })
      const updated = await updateTache(req.params.id, req.body)
      if (req.body.id_collaborateur !== undefined && req.body.id_collaborateur !== tache.id_collaborateur) {
        notifierTacheAssignee(updated, { id: req.user.id, role: req.user.role })
      }
      return res.json(updated)
    }
    // Un collaborateur ne peut modifier que le statut (et le membre concerné en cas
    // de problème de coordination) de ses propres tâches — jamais le titre,
    // l'échéance ou la réaffectation à quelqu'un d'autre.
    if (req.user.role === 'collaborateur') {
      const tache = await getTacheById(req.params.id)
      if (!tache) return res.status(404).json({ message: 'Tâche introuvable.' })
      if (tache.id_collaborateur !== req.user.id) {
        return res.status(403).json({ message: 'Vous ne pouvez modifier que vos propres tâches.' })
      }
      const { statut, membre_concerne } = req.body
      if (!STATUTS_AUTORISES_COLLABORATEUR.includes(statut)) {
        return res.status(400).json({ message: 'Statut invalide.' })
      }
      if (statut === 'probleme_coordination' && !String(membre_concerne || '').trim()) {
        return res.status(400).json({ message: 'Veuillez préciser le membre concerné.' })
      }
      const updated = await updateTache(req.params.id, {
        statut,
        membre_concerne: statut === 'probleme_coordination' ? membre_concerne.trim() : null,
      })
      return res.json(updated)
    }
    const tacheAvant = await getTacheById(req.params.id)
    const updated = await updateTache(req.params.id, req.body)
    if (req.body.id_collaborateur !== undefined && req.body.id_collaborateur !== tacheAvant?.id_collaborateur) {
      notifierTacheAssignee(updated, { id: req.user.id, role: req.user.role })
    }
    res.json(updated)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Erreur serveur' })
  }
}

export async function removeTache(req, res) {
  try {
    if (req.user.role === 'responsable') {
      const tache = await getTacheById(req.params.id)
      if (!tache) return res.status(404).json({ message: 'Tâche introuvable.' })
      const ok = await sousEquipeAppartientAuResponsable(tache.id_sous_equipe, req.user.id)
      if (!ok) return res.status(403).json({ message: 'Vous ne pouvez supprimer que les tâches de votre équipe.' })
    }
    await deleteTache(req.params.id)
    res.status(204).end()
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Erreur serveur' })
  }
}

export async function listStatsImplication(req, res) {
  try {
    const { annee_universitaire, semestre } = req.query
    const stats = await getStatsImplication(annee_universitaire, semestre)
    res.json(stats)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Erreur serveur' })
  }
}